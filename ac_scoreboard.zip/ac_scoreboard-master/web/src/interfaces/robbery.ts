export interface Robbery {
    name: string;
    minimum : number;
    jobcount: number;
  }
  