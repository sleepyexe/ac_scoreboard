export interface Player {
  [key: string]: string;
}
