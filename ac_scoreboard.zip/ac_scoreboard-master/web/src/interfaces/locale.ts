export interface Locale {
  [key: string]: string;
}
