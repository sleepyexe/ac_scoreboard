export interface Group {
  label: string;
  count: number;
  separator?: true;
}
