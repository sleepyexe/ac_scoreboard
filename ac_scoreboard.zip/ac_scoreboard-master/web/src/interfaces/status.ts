export interface Status {
    name: string;
    minimum : number;
    jobcount: number;
  }
  