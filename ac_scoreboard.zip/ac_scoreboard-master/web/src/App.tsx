import Scoreboard from "./components/Scoreboard";

const App: React.FC = () => {
  return <Scoreboard />;
};

export default App;
