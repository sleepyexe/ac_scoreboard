import { useContext } from "react";
import { LocaleContext } from "../Scoreboard";
import { Stack, Flex, Text, Tag } from "@chakra-ui/react";
import type { Robbery } from "../../interfaces/robbery";
import SectionHeader from "./SectionHeader";
import { type } from "os";

interface Props {
  robs: Array<Robbery>;
}


const RobberyList: React.FC<Props> = (props: Props) => {
  const locales = useContext(LocaleContext);
    return (
        <Stack direction="column" spacing="1">
        <SectionHeader left={locales["ui_robbery"]} right={locales["ui_robbery_status"]} />
        {props.robs.map((robs, index) => (
            <>
            <Flex
                key={index}
                w="2xs"
                p={2}
                justifyContent="space-between"
                bg="gray.800"
                borderRadius={4}
            >
                <Text noOfLines={1} casing="uppercase" fontWeight="medium">
                {robs.name}
                </Text>
            
                {/* <Tag colorScheme={colorsByStatus[robs.services]}>
                {robs.services}
                </Tag> */}
                <Tag colorScheme={robs.minimum <= robs.jobcount ? "red" : "gray"}>
                {robs.minimum <= robs.jobcount ? "Bisa" : "Tidak Bisa"}
                </Tag>

            </Flex>
            </>
        ))}
        </Stack>
    );
};

export default RobberyList;
