import { useContext } from "react";
import { LocaleContext } from "../Scoreboard";
import { Stack, Flex, Text, Tag } from "@chakra-ui/react";
import type { Status } from "../../interfaces/status";
import SectionHeader from "./SectionHeader";
import { type } from "os";

interface Props {
  statuses: Array<Status>;
}


const StatusList: React.FC<Props> = (props: Props) => {
  const locales = useContext(LocaleContext);
    return (
        <Stack direction="column" spacing="1">
        <SectionHeader left={locales["ui_services_name"]} right={locales["ui_services"]} />
        {props.statuses.map((statuses, index) => (
            <>
            <Flex
                key={index}
                w="2xs"
                p={2}
                justifyContent="space-between"
                bg="gray.800"
                borderRadius={4}
            >
                <Text noOfLines={1} casing="uppercase" fontWeight="medium">
                {statuses.name}
                </Text>
            
                <Tag colorScheme={statuses.minimum <= statuses.jobcount ? "red" : "gray"}>
                {statuses.minimum <= statuses.jobcount ? "Buka" : "Tutup"}
                </Tag>

            </Flex>
            </>
        ))}
        </Stack>
    );
};

export default StatusList;
