return {
	['ui_group'] = "Count",
	['ui_count'] = "Group",
	['ui_name'] = "Status",
	['ui_id'] = "Fitur/Tempat",
	['ui_player_count'] = "Player count",
	['ui_your_id'] = "Your server ID",
	['ui_copied'] = "Copied to clipboard!",
	['ui_restartTime'] = "Server Restart Time!",
	['ui_services'] = "Layanan",
	['ui_services_name'] = "Status",
	['ui_robbery_status'] = "Robbery",
	['ui_robbery'] = "Status",

	['command_open'] = "Opens the scoreboard UI",
	['keymap_open'] = "Open scoreboard UI",
}
